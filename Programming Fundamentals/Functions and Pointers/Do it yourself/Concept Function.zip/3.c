#include<stdio.h>
void grade(int avg_marks)
{
    if(avg_marks>80)
        printf("Excellent\n");
    else if(avg_marks>70)
        printf("Good\n");
    else if(avg_marks>60)
        printf("Fair\n");
}
int main()
{
    int a[5],sum=0,i;
    printf("Enter your marks in 5 subjects : \n");
    for(i=0;i<5;i++)
    {
         scanf("%d",&a[i]);
         sum=sum+a[i];
    }
    sum=sum/5;
    grade(sum);




}
