#include<stdio.h>
void change(int a[],int n)
{
    int i;
    for(i=0;i<n;i++)
        if(a[i]==11060)
        a[i]=12050;



}
int main()
{
    int a[]={11060,2003,2106,52003,11060,87645};
    int n=6,i;

    printf("Array Initially : \n");
    for(i=0;i<n;i++)
        printf("%d ",a[i]);
        printf("\n");
    change(a,n);
    printf("Array After Changing : \n");
    for(i=0;i<n;i++)
        printf("%d ",a[i]);

    return 0;
}
